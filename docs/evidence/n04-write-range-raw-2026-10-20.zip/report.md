# N04 bounded byte writes range-write-2026-10-20 / sampling-1000-vm-20

All raw samples, warmups and failures are retained in results.json. No trimming or retries.

| Phase | Case | Samples | Metric | Median ns | CPU ms | Peak RSS KiB | Statistics stable | Session qualified |
| --- | --- | ---: | --- | ---: | ---: | ---: | --- | --- |
| comparison | slice-copy-64k-wio-native | 1000 | kernel | 1.61018e+07 | 62.5 | 9320 | no | no |
| comparison | slice-copy-64k-wio-vm | 20 | kernel | 1.66176e+09 | 4476.56 | 27920 | yes | no |
| comparison | slice-copy-64k-cpp | 1000 | kernel | 8.06575e+06 | 31.25 | 5440 | no | no |
| comparison | slice-copy-64k-csharp | 1000 | kernel | 2.3071e+06 | 93.75 | 37080 | no | no |
| comparison | borrow-range-64k-wio-native | 1000 | kernel | 879950 | 15.625 | 9316 | no | no |
| comparison | borrow-range-64k-wio-vm | 20 | kernel | 1.09825e+09 | 3031.25 | 24800 | no | no |
| comparison | borrow-range-64k-cpp | 1000 | kernel | 863050 | 15.625 | 5436 | no | no |
| comparison | borrow-range-64k-csharp | 1000 | kernel | 786850 | 78.125 | 24528 | no | no |
| final | slice-copy-64k-wio-native | 1000 | kernel | 1.67494e+07 | 62.5 | 9320 | no | no |
| final | slice-copy-64k-wio-vm | 20 | kernel | 1.64311e+09 | 4445.31 | 27936 | yes | no |
| final | borrow-range-64k-wio-native | 1000 | kernel | 1.04605e+06 | 15.625 | 9316 | no | no |
| final | borrow-range-64k-wio-vm | 20 | kernel | 1.1108e+09 | 3070.31 | 24818 | yes | no |

Kernel time excludes process startup; wall time includes startup and polling.
Child CPU/peak RSS cover the root process; allocation diagnostics are separate and optional.
Approximate mean 95% intervals are descriptive normal intervals, not a universal accuracy guarantee.

Outputs correct: yes; overall timing qualified: no.
