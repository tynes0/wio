# N04 legacy Write versus borrowed WriteBlock / sampling-1000-vm-20

All raw samples, warmups and failures are retained in results.json. No trimming or retries.

| Phase | Case | Samples | Metric | Median ns | CPU ms | Peak RSS KiB | Statistics stable | Session qualified |
| --- | --- | ---: | --- | ---: | ---: | ---: | --- | --- |
| comparison | legacy-wio-native | 1000 | kernel | 1.28088e+07 | 46.875 | 9192 | no | no |
| comparison | legacy-wio-vm | 20 | kernel | 2.12986e+08 | 539.062 | 18060 | no | no |
| comparison | block-wio-native | 1000 | kernel | 20200 | 15.625 | 9168 | no | no |
| comparison | block-wio-vm | 20 | kernel | 1.36576e+07 | 70.3125 | 18172 | no | no |
| comparison | block-cpp | 1000 | kernel | 1000 | 15.625 | 5200 | no | no |
| comparison | block-csharp | 1000 | kernel | 900 | 78.125 | 24036 | no | no |
| final | legacy-wio-native | 1000 | kernel | 1.28169e+07 | 46.875 | 9192 | no | no |
| final | legacy-wio-vm | 20 | kernel | 2.07473e+08 | 531.25 | 18060 | no | no |
| final | block-wio-native | 1000 | kernel | 20100 | 15.625 | 9168 | no | no |
| final | block-wio-vm | 20 | kernel | 1.30295e+07 | 62.5 | 18168 | no | no |

Kernel time excludes process startup; wall time includes startup and polling.
Child CPU/peak RSS cover the root process; allocation diagnostics are separate and optional.
Approximate mean 95% intervals are descriptive normal intervals, not a universal accuracy guarantee.

Outputs correct: yes; overall timing qualified: no.
