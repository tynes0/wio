# N04 owned byte I/O inline-owning-cell / owning-place-after / sampling-1000-vm-20

All raw samples, warmups and failures are retained in results.json. No trimming or retries.

| Phase | Case | Samples | Metric | Median ns | CPU ms | Peak RSS KiB | Statistics stable | Session qualified |
| --- | --- | ---: | --- | ---: | ---: | ---: | --- | --- |
| comparison | exact-64k-wio-native | 1000 | kernel | 4.51612e+07 | 125 | 9292 | no | no |
| comparison | exact-64k-wio-vm | 20 | kernel | 2.50698e+09 | 6835.94 | 24824 | no | no |
| comparison | exact-64k-cpp | 1000 | kernel | 4.61134e+07 | 109.375 | 5420 | no | no |
| comparison | exact-64k-csharp | 1000 | kernel | 3.37026e+07 | 171.875 | 36996 | no | no |
| comparison | some-64k-wio-native | 1000 | kernel | 4.43462e+07 | 125 | 9292 | no | no |
| comparison | some-64k-wio-vm | 20 | kernel | 2.521e+09 | 6750 | 24812 | no | no |
| comparison | some-64k-cpp | 1000 | kernel | 4.57471e+07 | 109.375 | 5420 | no | no |
| comparison | some-64k-csharp | 1000 | kernel | 3.40072e+07 | 171.875 | 36996 | no | no |
| final | exact-64k-wio-native | 1000 | kernel | 2.75034e+07 | 93.75 | 9292 | no | no |
| final | exact-64k-wio-vm | 20 | kernel | 2.51278e+09 | 6976.56 | 24844 | yes | no |
| final | some-64k-wio-native | 1000 | kernel | 2.75378e+07 | 93.75 | 9292 | no | no |
| final | some-64k-wio-vm | 20 | kernel | 2.54853e+09 | 7070.31 | 24832 | no | no |

Kernel time excludes process startup; wall time includes startup and polling.
Child CPU/peak RSS cover the root process; allocation diagnostics are separate and optional.
Approximate mean 95% intervals are descriptive normal intervals, not a universal accuracy guarantee.

Outputs correct: yes; overall timing qualified: no.
